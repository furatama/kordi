<?php

namespace App;

use App\AppForm;

class FormKoorL1 extends AppForm
{
}
